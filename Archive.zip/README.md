Run general Data to get statistic 


Run createExcel to generate excel file in the right format
default output.csv you can modify and use this file in the main.py
Should use the original data to create the right format data for using later.

Run main.py
Example run on sample.xlsx 


statistic error, and predicted concentration
